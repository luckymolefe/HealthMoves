How to use


Web instructions: 
1. Hit CTRL+U to view the source of this page
2. Copy the line starting with @font-face in the style tag of the source; make sure you copy all of it
3. Paste that line in your own CSS file or style tag
4. Also copy the 4 font files required: EOT, SVG, WOFF, TTF
5. Update paths in the CSS line as required


For Illustrator 
1. Install the font (google for platform instructions)
2. Open Illustrator (it will hang 2-3 seconds to update its internal font cache)
3. Create a normal writing (text) area
4. Open Type > Glyphs
5. Find an icon then double click it


Other GFX software 
1. Install the font and use something like charmap.exe to find & copy glyphs


To get circles or double circles 
1. Insert any icon
2. Put text cursor before the icon
3. Press "o" or "O" (uppercase or lowercase Oslo)