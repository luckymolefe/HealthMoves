<?php
	
	//db connection settings
	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="healthymoves"; // Database name

	try {
		$conn = new PDO("mysql:host=".$host.";dbname=".$db_name, $username, $password); //initialize database connection
	}
	catch(PDOException $e) {
		echo "MYSQL_DB ERROR: ".$e->getMessage(); //throw any error message
	}

?>