<?php

//all notifications, including specials sales and promotions
echo "Page will display list of messages send by admin";

?>