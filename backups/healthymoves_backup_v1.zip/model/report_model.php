<?php
	//Reports Model
	require_once('order_model.php');
/**
 * 
 */
class Reports extends Orders {
	private $conn = null;

	public function __construct() {
		global $conn;
		$this->conn = $conn;
	}

	public function countAllProducts() {
		$stmt = $this->conn->prepare('SELECT id FROM products');
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countAllOrders() {
		$stmt = $this->conn->prepare("SELECT order_id FROM orders");
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function getPendingOrders() {
		$stmt = $this->conn->prepare("SELECT order_id FROM orders WHERE order_status = 0");
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countPaidOrders() {
		$stmt = $this->conn->prepare("SELECT order_id FROM orders WHERE order_status = 1");
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countAllCustomers() {
		$stmt = $this->conn->prepare("SELECT id FROM customers");
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countDepositTransactions() {
		$paytype = "deposit";
		$stmt = $this->conn->prepare("SELECT order_id FROM orders WHERE payment_type = ?");
		$stmt->bindValue(1, $paytype);
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countEftTransactions() {
		$paytype = "eft";
		$stmt = $this->conn->prepare("SELECT order_id FROM orders WHERE payment_type = ?");
		$stmt->bindValue(1, $paytype);
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countAllCreditTransactions() {
		$paytype = "creditcard";
		$stmt = $this->conn->prepare("SELECT order_id FROM orders WHERE payment_type = ?");
		$stmt->bindValue(1, $paytype);
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function countAllCategories() {
		$stmt = $this->conn->prepare("SELECT id FROM categories");
		$stmt->execute();
		return $stmt->rowCount();
	}

	public function totalAmount() {
		$stmt = $this->conn->prepare("SELECT SUM(order_total) AS totalAmount FROM orders");
		$stmt->execute();
		if($stmt->rowCount() > 0) {
			return $stmt->fetch(PDO::FETCH_OBJ);
		} else {
			return 0;
		}
	}

	public function totalPaidInv() {
		$stmt = $this->conn->prepare("SELECT SUM(order_total) AS totalPaid FROM orders WHERE order_status = 1");
		$stmt->execute();
		if($stmt->rowCount() > 0) {
			return $stmt->fetch(PDO::FETCH_OBJ);
		} else {
			return "0";
		}
	}

	public function totalunPaidInv() {
		$stmt = $this->conn->prepare("SELECT SUM(order_total) AS totalUnPaid FROM orders WHERE order_status = 0");
		$stmt->execute();
		if($stmt->rowCount() > 0) {
			return $stmt->fetch(PDO::FETCH_OBJ);
		} else {
			return 0;
		}
	}

}
$report = new Reports();

?>