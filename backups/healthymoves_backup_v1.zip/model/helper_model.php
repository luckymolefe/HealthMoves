<?php

session_start();

abstract class Helper {
	private $data = null;
	private $sanitized_data = null;
	private $cipher = null;
	private $secretKey = null;
	private $secret_iv = null;
	private $key = null;
	private $vector = null;

	//sanitize/clean all input data that was submitted
	public static function sanitize($params) {
		$sanitized_data = array();
		foreach($params as $k => $v) {
			$sanitized_data[$k] = htmlentities(stripslashes(strip_tags(trim($v)))); 
		}
		return $sanitized_data;
	}
	//call method internally to hash data
	protected function hash_data($data) {
		$this->data = $data;
		return sha1($this->data);
	}
	//call to to break and wrap text
	public function wrapText($data) {
		if(strlen($data) > 15) {
			$data = substr($data, 0, 15).'...';
			return $data;
		} else {
			return $data;
		}
	}
	//call method to initialize encryption variables
	private function initCrypt() {
		//Set up the variables for initialize encryption
		$this->cipher = 'AES-256-CBC';
		$this->secretKey = SHA1('mIcK3yM0u53$Up3r53cR3+'); //use the SHA1 function to generate a key
		$this->secret_iv = 'eaiYYkYTysia2lnHiw0N0';
		$this->key = hash('sha256', $this->secretKey);
		$this->vector = substr(hash('sha256', $this->secret_iv), 0, 16);
	}
	//call to encrypt data
	public function data_encrypt($string) {
		$this->initCrypt();
		$this->data = $string;
		$this->data = openssl_encrypt($this->data, $this->cipher, $this->key, 0, $this->vector);
		return base64_encode($this->data);
	}
	//call to decrypt data
	public function data_decrypt($string) {
		$this->initCrypt();
		$this->data = base64_decode($string);
		$this->data = openssl_decrypt($this->data, $this->cipher, $this->key, 0, $this->vector);
		return $this->data;
	}
}


?>