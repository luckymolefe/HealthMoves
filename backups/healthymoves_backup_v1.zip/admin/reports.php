<?php
	//Generate Statistics Reports
	require_once('../model/report_model.php');

	$allCust = $report->countAllCustomers();
	$allproducts = $report->countAllProducts();
	$allorders = $report->countAllOrders();

	$pending = $report->getPendingOrders();
	$paid = $report->countPaidOrders();
	$alleft = $report->countEftTransactions();

	$alldep = $report->countDepositTransactions();
	$alltransact = $report->countAllCreditTransactions();
	$allcatgry = $report->countAllCategories();

	$tunover = $report->totalAmount();
	$totalpaid = $report->totalPaidInv();
	$totalunpaid = $report->totalunPaidInv();
	
?>
<style type="text/css">
	.container {
		text-align: center;
	}
	.container-panel {
		width: 250px;
		height: 150px;
		max-width: 100%;
		margin: 0 auto;
		background-color: #eee;
		padding: 10px;
		border-radius: 2px;
		margin: 10px 10px 10px 0;
		box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.5);
		border-bottom: 3px solid #0c8e7e;
		display: inline-block;
		text-align: center;
		color: #005555;
		/*transform: scale(0);*/
	}
	.container-panel:hover {
		background-color: #ddd;
		/*background-color: #0c8e7e;*/
		/*color: #fff;*/
		border-bottom: 3px solid #034f99;
	}
	.page-heading {
		font-size: 2em;
		color: #777;
		border-bottom: thin solid #ccc;
		text-align: center;
		padding: 0 0 5px 0;
	}
	.panel-text {
		font-size: 1.5em;
		font-weight: bold;
	}
	.panel-stats {
		font-size: 5em;
		color: #034f99;
	}
	.small {
		margin-top: 20px;
		font-size: 2.5em;
		color: #fff !important;
	}
	.container-panel:nth-child(10) {
		background-color: #99ee99 !important;
		color: #fff;
	}
	.container-panel:nth-child(11) {
		background-color: #ee9999 !important;
		color: #fff;
	}
	.container-panel:nth-child(12) {
		background-color: #8888ff !important;
		color: #fff;
	}
	
</style>
<h1 class="page-heading"><i class="fa fa-line-chart"></i> Reports</h1>
<div class="container">
	<div class="container-panel">
		<div class="panel-text">All Customers</div>
		<div class="panel-stats"><?php echo $allCust; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">All Products</div>
		<div class="panel-stats"><?php echo $allproducts; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">All Orders</div>
		<div class="panel-stats"><?php echo $allorders; ?></div>
	</div>

	<div class="container-panel">
		<div class="panel-text">Unpaid Orders</div>
		<div class="panel-stats"><?php echo $pending; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">Paid Orders</div>
		<div class="panel-stats"><?php echo $paid; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">EFT Transactions</div>
		<div class="panel-stats"><?php echo $alleft; ?></div>
	</div>

	<div class="container-panel">
		<div class="panel-text">Deposit Transactions</div>
		<div class="panel-stats"><?php echo $alldep; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">Credit Transactions</div>
		<div class="panel-stats"><?php echo $alltransact; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">All Categories</div>
		<div class="panel-stats"><?php echo $allcatgry; ?></div>
	</div>

	<div class="container-panel">
		<div class="panel-text">Total Amount Value</div>
		<div class="panel-stats small">R<?php echo $tunover->totalAmount; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">Total unPaid</div>
		<div class="panel-stats small">R<?php echo $totalunpaid->totalUnPaid; ?></div>
	</div>
	<div class="container-panel">
		<div class="panel-text">Total Balance</div>
		<div class="panel-stats small">R<?php echo number_format(($tunover->totalAmount - $totalunpaid->totalUnPaid),2); ?></div>
	</div>

</div>