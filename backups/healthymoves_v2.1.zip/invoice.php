<?php

	
?>
<center>
<h1>Your transaction was successful</h1>
<p>Please note all information regarding your order will be sent to you by email shortly.</p>
<p>Want to continue shopping with us at Healthy Moves?<br/><a href="shop.php">Browse our Webstore</a>
<h3>Thank you for shopping with us!</h3>
</center>
