<?php
	//Order Model
	require_once('product_model.php');
	/**
	 * 
	 */
	class Orders extends Products {
		private $conn = null;

		public function __construct() {
			global $conn;
			$this->conn = $conn;
		}

		public function createOrder($params) {
			try {
			$orderID = $this->generateOrderNumber();
			$stmt = $this->conn->prepare("INSERT INTO orders (customer_id, order_id, order_quantity, order_total, ) VALUES (?, ?, ?, ?, ?)");
			$stmt->bindValue(1, $params['uid']);
			$stmt->bindValue(2, $orderID);
			$stmt->bindValue(3, $params['quantity']);
			$stmt->bindValue(4, $params['total']);
			$stmt->bindValue(5, $params['paytype']);
			if($stmt->execute()) {
				($params['paytype'] == "creditcard") ? $this->confirmOrder($orderID) : ''; //if customer used credit card for purchases, change orderStatus immediately after creating an order
				return true;
			}
			else {
				return false;
			}
			}
			catch(PDOException $e) {
				echo "Error: ".$e->getMessage();
			}
		}

		public function retrieveOrders() {
			$stmt = $this->conn->prepare("SELECT * FROM orders ORDER BY created");
			$stmt->execute();
			if($stmt->rowCount() > 0) {
				return $stmt->fetchAll(PDO::FETCH_OBJ);
			}
			else  {
				return false;
			}
		}

		public function getAllOrders($uid) {
			$stmt = $this->conn->prepare("SELECT * FROM orders WHERE customer_id = ?");
			$stmt->bindValue(1, $uid);
			$stmt->execute();
			if($stmt->rowCount() > 0) {
				return $stmt->fetchAll(PDO::FETCH_OBJ);
			}
			else  {
				return false;
			}
		}

		public function readOrder($orderId) {
			$stmt = $this->conn->prepare("SELECT * FROM orders WHERE order_id = ?");
			$stmt->bindValue(1, $orderId);
			$stmt->execute();
			if($stmt->rowCount() > 0) {
				return $stmt->fetch(PDO::FETCH_OBJ);
			} else {
				return false;
			}
		}

		public function confirmOrder($orderId) {
			$orderStatus = 1;
			$stmt = $this->conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
			$stmt->bindValue(1, $orderStatus);
			$stmt->bindValue(2, $orderId);
			if($stmt->execute()) {
				return true;
			} else {
				return false;
			}
		}

		private function generateOrderNumber() {
			return rand(1000, 99000);
		}

	}
	$order = new Orders();
	/*$params = array('uid'=>1,'quantity'=>3,'total'=>'230.50');
	if($order->createOrder($params)) {
		echo "data saved";
	} else {
		echo "data failed";
	}*/
?>