<?php
	//Print Invoice Page
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewpoint" content="width=device-width, initital-scale=1.0">
		<title>Document Title</title>
		<style type="text/css">
			body {
				font-family: helvetica, airal;
			}
			.table-info {
				width: 100%;
				/*border: thin solid #777;*/
			}
			.table-info tr td:nth-of-type(2) {
				text-align: right;
				vertical-align: text-top;
			}
			.table-payment {
				text-align: center;
				width: 100%;
				border: thin solid #777;
				padding: 5px;
			}
			.table-payment thead th {
				background-color: #fec;
				border-bottom: 2px solid #777;
				padding: 15px 0;
			}
			.table-payment tr td {
				padding: 10px 0;
				/*border-bottom: thin solid #777;*/
			}
			.table-payment tr:last-child {
				font-size: 1.5em;
			}
			.table-payment tr:last-child td {
				border-top: 1px solid #777;
			}
			.lead {
				text-align: center;
				font-size: 1.8em;
			}
			.logo {
				width: 130px;
				max-width: 100%;
			}
			.header {
				font-size: 1.3em;
				font-weight: bold;
				padding: 8px 0;
				/*margin-top: 20px;*/
			}
			.footer {
				text-align: center;
				padding: 10px;
				border-top: thin solid #ccc;
				margin-top: 50px;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<table border="0" class="table-info">
				<tr>
					<td><center><img src="images/logo.png" class="logo"></center></td>
					<td>
						<div class="header">Healthy Moves</div>
						<div><small>(Business Address)</small> 123 Street Address, City, ZipCode</div>
						<div>Tel: 012 123 4567</div>
						<div>Cell: 082 123 4567</div>
					</td>
				</tr>
				<tr style="background-color: #eee;">
					<td  colspan="4">
						<div class="header">Invoice #0000</div>
						<div>Invoice Date: 01/01/2018</div>
						<div>Account Name: FNB - Acc No:(62270185583) - Type: (Cheque)</div>
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<div class="header">Invoice To:</div>
						<div>Lucky Molefe</div>
						<div><small>(Customer Address)</small>155 Street, City, Code</div>
						<div>Email: luckmolf@company.com</div>
						<div>081 553 2930</div>
					</td>
				</tr>
			</table>

			<table border="0" class="table-payment">
				<h4 class="lead">Order Summary</h4>
				<thead>
					<th>Item</th>
					<th>Quantity</th>
					<th>Total</th>
				</thead>
				<tbody>
					<tr>
						<td>Vitamin C</td>
						<td>1</td>
						<td align="right">R188.85</td>
					</tr>
					<tr style="background-color: #eee;">
						<td colspan="2" align="right">SubTotal</td>
						<td align="right">R188.85</td>
					</tr>
					<tr style="background-color: #eee;">
						<td colspan="2" align="right">15% VAT</td>
						<td align="right">R28.32</td>
					</tr>
					<tr style="background-color: #eee;">
						<td colspan="2" align="right">Total</td>
						<td align="right">R217.17</td>
					</tr>
				</tbody>
			</table>
			<div class="footer">
				<div class="lead">Thank You For Shopping With Us</div>
				<div><small>Healthy Moves &copy; 2018</small></div>
			</div>
		</div>
	</body>
</html>
